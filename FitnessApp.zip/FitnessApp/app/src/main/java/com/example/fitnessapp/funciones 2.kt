package com.example.splash

import java.math.RoundingMode
import java.text.DecimalFormat
import java.math.*

fun grasahombre(cintura: Double, cuello:Double, altura: Double):Double{
    val uno = 495
    val dos = 1.0324
    val tres = 0.19077
    val cua = 0.15456
    val cinco = 450
    var resw = (uno / (dos - tres * (Math.log(cintura-cuello))+ cua * (Math.log(altura)))-cinco)
    return covertDeci( resw.toDouble())
}


fun grasamujer (cintura: Double,cadera: Double, cuello:Double, altura: Double):Double{
    val unos = 495
    val doss = 1.29579
    val tress = 0.35004
    val cuas = 0.22100
    val cincos = 450
    var resws = unos / (doss - tress * (Math.log(cintura-cuello))+ cuas * (Math.log(altura)))-cincos
    return  covertDeci( resws.toDouble())
}

fun covertDeci(n2:Double):Double {
    val df = DecimalFormat("#.##")
    df.roundingMode = RoundingMode.CEILING
    var d = ""
    d = df.format(n2)
    return d.toDouble()
}


