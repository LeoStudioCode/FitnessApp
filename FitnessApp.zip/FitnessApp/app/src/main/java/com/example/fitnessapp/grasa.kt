package com.example.splash

import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.example.fitnessapp.R
import com.example.fitnessapp.databinding.ActivityGrasaBinding
class grasa : AppCompatActivity() {
    private lateinit var binding: ActivityGrasaBinding
    private var vel :Double = 0.0

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_grasa)
        binding = ActivityGrasaBinding.inflate(layoutInflater)
        setContentView(binding.root)
        val actionBar = supportActionBar
        actionBar!!.hide()

        binding.btnh.setOnClickListener {
            if(binding.alturaH.text.toString().isEmpty() || binding.cinturaH.text.toString().isEmpty() || binding.cuelloH.text.toString().isEmpty()) {
                Toast.makeText(this, "Rellene todos los campos", Toast.LENGTH_SHORT).show()
            }else{
                vel = grasahombre(binding.cinturaH.text.toString().toDouble(),binding.cuelloH.text.toString().toDouble(),binding.alturaH.text.toString().toDouble())
                binding.resu.text = "Usted tiene: " + (vel).toString() + "% de grasa"
            }
        }
    }
    override fun onSaveInstanceState(outState: Bundle){
        super.onSaveInstanceState(outState)
        outState.putDouble("Su grasa es", vel)
    }
    override fun onRestoreInstanceState(savedInstanceState: Bundle) {
        super.onRestoreInstanceState(savedInstanceState)
        vel = savedInstanceState.getDouble("Su grasa es")
        binding.resu.setText("Usted tiene: " + (vel).toString() + "% de grasa")
    }
}

