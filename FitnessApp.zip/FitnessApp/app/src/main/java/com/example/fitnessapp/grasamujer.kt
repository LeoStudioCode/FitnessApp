package com.example.splash

import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.example.fitnessapp.R
import com.example.fitnessapp.databinding.ActivityGrasamujerBinding

class grasamujer : AppCompatActivity() {
    private lateinit var binding: ActivityGrasamujerBinding
    private var la: Double = 0.0
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_grasamujer)

        binding = ActivityGrasamujerBinding.inflate(layoutInflater)
        setContentView(binding.root)
        val actionBar = supportActionBar
        actionBar!!.hide()


        binding.btncal.setOnClickListener {
            if (binding.cveAltura.text.toString().isEmpty() || binding.pe.text.toString()
                    .isEmpty() ||
                binding.cvePeriCuello.text.toString()
                    .isEmpty() || binding.cvePeriCadera.text.toString().isEmpty()
            ) {

                Toast.makeText(this, "Rellene todos los campos", Toast.LENGTH_LONG).show()
            } else {
                la = grasamujer(
                    binding.pe.text.toString().toDouble(),
                    binding.cvePeriCadera.text.toString().toDouble(),
                    binding.cvePeriCuello.text.toString().toDouble(),
                    binding.cveAltura.text.toString().toDouble()
                )
                binding.idres.text = "Usted tiene: " + (la).toString() + " % de grasa"
            }
        }
    }

    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        outState.putDouble("Su grasa es: " ,la)
    }

    override fun onRestoreInstanceState(savedInstanceState: Bundle) {
        super.onRestoreInstanceState(savedInstanceState)
        la = savedInstanceState.getDouble("Su grasa es: ")
        binding.idres.setText( "Usted tiene: " + (la).toString() + " % de grasa")
    }
}