import java.math.RoundingMode
import java.text.DecimalFormat
import java.math.*
import kotlin.math.log
import kotlin.math.log10

//Funcion del hombre en este caso calculamos la edad,altura,peso para ello
//la formula ya especificada trae variables para ambos casos tanto el de la mujer
//como la del hombre, en este caso tenemos que realizar bien la jerarquia de operaciones
fun hombre(peso: Float, altura:Float, edad: Float): Float {

    var para1 = 66.47;
    var para2 = 13.75;
    var para3 = 5;
    var para4 = 6.76;
    var resultado = (para1 + (para2 * peso) + (para3 * altura) - (para4 * edad))
    return covertDec(resultado.toFloat())
}

fun mujer(peso: Float, altura:Float, edad: Float):Float{

    val paras1 = 655.1;
    val paras2 = 9.56;
    val paras3 = 1.85;
    val paras4 = 4.68;
    var resultado = (paras1 + (paras2 * peso) + (paras3 * altura) - (paras4 * edad))
    return covertDec(resultado.toFloat())

}


fun covertDec(n1:Float):Float {
    val df = DecimalFormat("#.##")
    df.roundingMode = RoundingMode.CEILING
    var dato = ""
    dato = df.format(n1)
    return dato.toFloat()
}













