package com.example.fitnessapp

import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.example.fitnessapp.databinding.ActivityBotonesIBinding

class BotonesI : AppCompatActivity() {

    private lateinit var binding: ActivityBotonesIBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_botones_i)
        val actionBar = supportActionBar
        actionBar!!.hide()

        binding = ActivityBotonesIBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.grasas.setOnClickListener {
            val r1: Intent = Intent(this,Sexo::class.java)
            startActivity(r1)
        }
        binding.calorias.setOnClickListener {
            val r2: Intent = Intent(this, MainActivity::class.java)
            startActivity(r2)
        }


    }
}