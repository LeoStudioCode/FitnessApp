package com.example.fitnessapp

import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.example.fitnessapp.databinding.ActivitySexoBinding

class Sexo : AppCompatActivity() {
    private lateinit var binding: ActivitySexoBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val actionBar = supportActionBar
        actionBar!!.hide()

        binding = ActivitySexoBinding.inflate(layoutInflater)
        setContentView(binding.root)




        binding.m.setOnClickListener {
            val r1: Intent = Intent(this,grasa::class.java)
            startActivity(r1)
        }
        binding.f.setOnClickListener {
            val r1: Intent = Intent(this,grasamujer::class.java)
            startActivity(r1)
        }



    }
}