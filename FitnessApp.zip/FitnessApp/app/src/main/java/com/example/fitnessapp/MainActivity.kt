package com.example.fitnessapp

import android.content.Intent
import android.os.Bundle
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.example.fitnessapp.databinding.ActivityMainBinding
import hombre
import mujer


class MainActivity : AppCompatActivity() {
    private lateinit var binding: ActivityMainBinding
    private var rs:Float = 0.0F
    private var df:Float = 0.00F
    private lateinit var resultado: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)
        val actionBar = supportActionBar
        actionBar!!.hide()

        binding.salir?.setOnClickListener {
            val r1: Intent = Intent(this,BotonesI::class.java)
            startActivity(r1)
        }

        binding.btncalcular.setOnClickListener {
            when {
                // en esta caso la funcio se mando a llamar con sus parametros bien estructurados
                //va checar la funcion si es verdadero la funcion va tener un resultado, en este caso
                //si no se rellena algun dato no lo va recibir y va mandar un mensaje
                binding.hombre1.isChecked -> if (binding.idedad.text.isNotEmpty() && binding.idpeso.text.isNotEmpty() && binding.idaltura.text.isNotEmpty()) {
                     rs = hombre(
                        binding.idpeso.text.toString().toFloat(),
                        binding.idaltura.text.toString().toFloat(),
                        binding.idedad.text.toString().toFloat())
                    // resultado.setText("Necesita: ${(rs)} calorias")

                    binding.btn2.text = "Necesita: " + (rs).toString() + " calorías"
                } else {
                    Toast.makeText(applicationContext, "Complete los campos", Toast.LENGTH_LONG).show()
                }
                binding.mujer2.isChecked -> if (binding.idedad.text.isNotEmpty() && binding.idpeso.text.isNotEmpty() && binding.idaltura.text.isNotEmpty()) {
                     rs = mujer(
                        binding.idedad.text.toString().toFloat(),
                        binding.idaltura.text.toString().toFloat(),
                        binding.idpeso.text.toString().toFloat()).toFloat()
                    //Poner solo dos decimal al resultado

                    binding.btn2.text = "Necesita: " + (rs).toString() + " calorías"
                } else {
                    Toast.makeText(applicationContext, "Complete los campos", Toast.LENGTH_LONG).show()
                }
            }
        }
    }
    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        outState.putFloat("Su requerimineto", rs)
    }
    override fun onRestoreInstanceState(savedInstanceState: Bundle) {
        super.onRestoreInstanceState(savedInstanceState)
        rs = savedInstanceState.getFloat("Su requerimineto")
        binding.btn2.setText("Necesita: " + (rs).toString() + " calorías")
    }
}

